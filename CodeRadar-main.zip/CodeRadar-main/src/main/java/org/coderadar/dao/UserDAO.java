package org.coderadar.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.springframework.stereotype.Repository;

@Mapper
public interface UserDAO {

    @Insert("INSERT INTO user(account,username,password_hash) VALUES ('test05','test','test')")
    public void testAddUser();
}
