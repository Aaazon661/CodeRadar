package org.coderadar.dao;

public interface SuggestionDAO {
}
