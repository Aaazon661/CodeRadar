package org.coderadar.dao;

public interface FileDAO {
}
