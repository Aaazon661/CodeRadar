package org.coderadar.dao;

public interface ResultDAO {
}
