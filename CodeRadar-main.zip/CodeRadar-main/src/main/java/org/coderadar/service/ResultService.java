package org.coderadar.service;

public interface ResultService {
}
