package org.coderadar.service;

public interface FileService {
}
