package org.coderadar.service;

public interface UserService {
}
