package org.coderadar.service.impl;

public class SuggestionServiceImpl {
}
