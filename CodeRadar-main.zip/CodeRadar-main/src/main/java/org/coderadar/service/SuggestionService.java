package org.coderadar.service;

public interface SuggestionService {
}
